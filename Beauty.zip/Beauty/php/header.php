<header id="header">
    <nav class="navbar navbar-expand-lg " ;>
        <a href="index (2).php" class="navbar-brand  text-danger" style="font-family: impact">
            <h3 class="px-5" style="margin-left: 25%">
                <i class="fas fa-shopping-basket " >ALOHA SHOPPING PRODUCTS</i>
            </h3>


        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
            aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="mr-auto"></div>
            <div class="navbar-nav" style=" margin-right: 10%">
                <a href="cart.php" class="nav-item nav-link active text-danger">
                    <h5 class="px-5 cart">
                        <i class="fas fa-shopping-cart text-danger"></i>My CART
                        <?php

                        if (isset($_SESSION['cart'])){
                            $count = count($_SESSION['cart']);
                            echo "<span id=\"cart_count\" class=\"text-warning bg-light\">$count</span>";
                        }else{
                            echo "<span id=\"cart_count\" class=\"text-warning bg-light\">0</span>";
                        }

                        ?>
                    </h5>
                </a>
            </div>
        </div>
                  <a class="fas text-danger" style=" margin-right: 20%" href="index.php">HOME</a>
    </nav>
</header>