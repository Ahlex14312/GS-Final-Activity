<?php

function component($productname, $productprice, $productimg, $productid){
    $element = "
    
    <div class=\"col-md-3 col-sm-6 my-3 my-md-0\">
                <form action=\"index (2).php\" method=\"post\">
                    <div class=\"card shadow\">
                        <div>
                            <img src=\"$productimg\" alt=\"Image1\" class=\"img-fluid card-img-top\">
                        </div>
                        <div class=\"card-body\">
                            <h5 class=\"card-title\">$productname</h5>
                            <h6>
                                <i class=\"fas fa-star\"></i>
                                <i class=\"fas fa-star\"></i>
                                <i class=\"fas fa-star\"></i>
                                <i class=\"fas fa-star\"></i>
                                <i class=\"far fa-star\"></i>
                            </h6>
                            <p class=\"card-text\">
                                Product Definition.
                            </p>
                            <h5>
                                <small><s>P</s></small>
                                <span class=\"price\">$productprice</span>
                            </h5>

                            <button type=\"submit\" class=\"btn btn-warning my-3\" name=\"add\"> Add to Cart <i class=\"fas fa-shopping-cart\"></i></button>
                             <input type='hidden' name='product_id' value='$productid'>
                        </div>
                    </div>
                    <br>
                    <br>
                    <br>
                </form>
            </div>
    ";
    echo $element;
}

function cartElement($productimg, $productname, $productprice, $productid){
    $element = "
    
    <form action=\"cart.php?action=remove&id=$productid\" method=\"post\" class=\"cart-items\">
                    <div class=\"border rounded\">
                        <div class=\"row bg-white\">
                            <div class=\"col-md-3 pl-0\">
                                <img src=$productimg alt=\"Image1\" class=\"img-fluid\">
                            </div>
                            <div class=\"col-md-6\">
                                <h5 class=\"pt-2\">$productname</h5>
                                <small class=\"text-secondary\">Seller: ALOHA Beauty Regain</small>
                                <h5 class=\"pt-2\">₱ $productprice</h5>
                        
                                <button type=\"submit\" class=\"btn btn-danger mx-2\" name=\"remove\">Remove</button>
                            </div>
                            <div class=\"defnumber-input number-input safari_only mb-0 col-md-3 py-5\">
                      <button type=\"button\"onclick=\"this.parentNode.querySelector('input[type=number]').stepDown()\"
                        class=\"minus decrease\"><i class=\"fas fa-minus\"></i></button>
                      <input class=\"quantity form-control w-50 d-inline\" min=\"0\" name=\"quantity\" value=\"1\" type=\"number\">
                      <button type=\"button\" onclick=\"this.parentNode.querySelector('input[type=number]').stepUp()\"
                        class=\"plus increase\"><i class=\"fas fa-plus\"></i></button>
                    </div>
                    <small id=\"passwordHelpBlock\" class=\"form-text text-muted text-center\">
                    </small>
                  </div>
                </div>
                <div class=\"d-flex justify-content-between align-items-center\">
                  <div>
                        </div>
                    </div>
                </form>
              
    
    ";
    echo  $element;
}


















