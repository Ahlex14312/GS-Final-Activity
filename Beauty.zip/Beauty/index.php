
<?php
session_start();
if(!isset($_SESSION['username'])){
header('location:signin.php');
exit;
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- external css -->
    <link rel="stylesheet" href="style1.css">
    <!-- bootstrap css -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut"
        crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k"
        crossorigin="anonymous"></script>
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <title>Aloha | Home</title>
    <link rel="icon" href="./images/logo.png" >
</head>
<style>
/* external css */
body {
    background-color: #f6f7f9
}
.custom-badge {
    background-color: #343a40 !important;
    color: #fff;
    font-size: 11px;
    padding: 5px;
    padding-left: 11px;
    padding-right: 11px;
    border-radius: 7px
}

.card {
    border: none;
    padding: 15px;
    cursor: pointer;
}


.time i {
    color: #cacacaa3
}

.gimg{
  height: 300px;  
}

</style>
<body>
<!-- nav bar -->
    <section id="nav-bar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#"><img src="./images/logo.png" ></a>
            <button class="navbar-toggler btn-outline-danger" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
              <ul class="navbar-nav">
                <li class="nav-item ">
                  <a class="nav-link" href="#">HOME</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="index (2).php">PRODUCTS</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="about.php" >ABOUT US</a>
                </li>
                  <li class="nav-item">
                    <a class="nav-link" href="logout.php" >SIGN OUT</a>
                  </li>
                </ul>
              </ul>
            </div>
          </nav>
    </section>
    <!-- home section -->
    <section id="banner">
        <div class = "container">
            <div class="row"> 
                <div class="col-md-6">
                <h1 class="promo-title text-danger fa-font-awesome-flag font-weight-bolder">Your doubt is our solution. </h1>
                <p></p>
                 <a href="#" id="message"><img id="gif" style="height: 30%;" src= "./images/play.gif">Watch our hottest products within.</a><br>
                  <a  id="message1" style="margin-left: 39% ;">Shines like a beauty Queen in your own.</a>
            </div>
            <div class="col-md-6">
            <img src="./images/centerpic.png" style="width:35rem; height:30rem" alt="centerpic">
            </div>
            </div>
        </div>
        <img src="./images/cp2.png" style="margin-top: -56%;" alt="lowerpic" class="img w-100">
    </section>
    <br><br><br>
    <!-- featured products -->
    <h1 style="text-align:center">Featured Products</h1>
    <br>
    <div class="container">
    <div class="row">
    <div class="col">
    <div class="card" style="width: 21rem;">
  <img class="card-img-top"><img src="images/feat1.jpg"  class="gimg">
  <div class="card-body">
  <div class="text-center">
    <h5 class="card-title">Translucent Powder</h5>
    <p class="card-text">Translucent Loose Setting Powder from Laura Mercier is a lightweight, easy-to-apply, loose powder that blends effortlessly to set makeup for up to 16 hours.</p>
    <a href="index (2).php" class="btn btn-warning">Visit Product</a>
  </div>
  </div>
</div>
</div>

<div class="col">
    <div class="card" style="width:21rem;">
  <img class="card-img-top"><img src="images/feat2.jpg"  class="gimg">
  <div class="card-body">
  <div class="text-center">
    <h5 class="card-title">Fenty Beauty</h5>
    <p class="card-text">Fenty Beauty Cheeks Out Freestyle Cream Bronzer ($32.00 for 0.22 oz.) is a new, permanent cream formula that can be used as bronzer and contour for beauty looks.</p>
    <a href="index (2).php" class="btn btn-warning">Visit Product</a>
    </div>
  </div>
</div>
</div>

<div class="col">
    <div class="card" style="width: 21rem;">
  <img class="card-img-top"><img src="images/feat3.jpg"  class="gimg">
  <img class="card-img-top">
  <div class="card-body">
  <div class="text-center">
    <h5 class="card-title">Matty Charcoal Spray</h5>
    <p class="card-text">Pur Matte Mist Anti-Pollution Setting Spray Lock in makeup and help protect your complexion with the beautiful, just-applied, shine-free matte finish of Matte Mist.</p>
    <a href="index (2).php" class="btn btn-warning">Visit Product</a>
</div>
</div>
</div>
</div>
<br><br>
<!-- give aways -->
<div class="container mt-5">
    <div class="d-flex justify-content-between align-items-center mb-3"> <span>Hottest Give aways</span> <span class="custom-badge text-uppercase text-warning">Buy Now</span> </div>
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex flex-row align-items-center time"> <i class="fa fa-clock-o"></i> <small class="ml-1 text-warning">3 Days</small> </div> <img src="https://i.imgur.com/suuFVrQ.png" width="20">
                </div><br>
                <div class="text-center"> <img src="images/give1.jpg" width="250" class="gimg"> </div><br>
                <div class="text-center">
                    <h5>Best Vegan + Nontoxic Skincare</h5> <span class="text-warning">Php 2,000.00 value</span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card" >
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex flex-row align-items-center time"> <i class="fa fa-clock-o"></i> <small class="ml-1 text-warning">00:02:13</small> </div> <img src="https://i.imgur.com/suuFVrQ.png" width="20">
                </div><br>
                <div class="text-center"> <img src="images/give2.jpg" width="250" class="gimg"> </div><br>
                <div class="text-center">
                    <h5>The Vault</h5> <span class="text-warning">Php 1,500.00 value</span>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="d-flex flex-row align-items-center time"> <i class="fa fa-clock-o"></i> <small class="ml-1 text-warning">2 Days</small> </div> <img src="https://i.imgur.com/suuFVrQ.png" width="20">
                </div><br>
                <div class="text-center"> <img src="images/give3.jpg" width="250" class="gimg"> </div><br>
                <div class="text-center">
                    <h5>On-the-Glow Blush</h5> <span class="text-warning">Php 1,250.00 value</span>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<br><br><br>
<!-- Present here are the social media where users can immediately contact -->
<footer class=" text-center text-dark " style="background-image: linear-gradient(to right, rgba(253, 231, 170, 0.467), rgb(243, 172, 19));">
  <!-- Grid container -->
  <div class="container p-4">
    <!-- Section: Social media -->
    <section class="mb-4">
      <!-- Facebook -->
      <br><br>
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.facebook.com/" role="button"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- Twitter -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.twitter.com/" role="button"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.google.com/" role="button"
        ><i class="fab fa-google"></i
      ></a>

      <!-- Instagram -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.instagram.com/" role="button"
        ><i class="fab fa-instagram"></i
      ></a>

      <!-- Linkedin -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.linkedin.com/" role="button"
        ><i class="fab fa-linkedin-in"></i
      ></a>

      <!-- Github -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.github.com/" role="button"
        ><i class="fab fa-github"></i
      ></a>
    </section>
    <!-- Section: Social media -->

    <!-- Section: Form -->
    <section class="">
      <form action="">
        <!--Grid row-->
        <div class="row d-flex justify-content-center">
          <!--Grid column-->
          <div class="col-auto">
            <p class="pt-2">
              <strong>Sign up for our comments and concerns:</strong>
            </p>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-md-5 col-12">
            <!-- Email input -->
            <div class="form-outline form-white mb-4">
              <input type="email" id="form5Example2" class="form-control" />
              <label class="form-label" for="form5Example2">Email address</label>
            </div>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-auto">
            <!-- Submit button -->
            <button type="submit" class="btn btn-outline-danger mb-4">
              Subscribe
            </button>
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </form>
    </section>
    <!-- Section: Form -->

    <!-- Section: Text -->
    <section class="mb-4">
      <p>
      Have fun playing with new lipsticks with new brand make ups! Make this look your own by shopping the products used on our Aloha Beauty Regain.
      </p>
    </section>

  <!-- Copyright -->
  <div class="text-center p-3" >
    © Group 2 @2021 Copyright:
    <br><br><br><br>
  </div>
  <!-- Copyright -->

</footer>
<img src="./images/cp2.png" style="margin-top: -67%;" alt="lowerpic" class="img w-100">
</body>
</html>
