<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aloha | About us</title>
    <link rel="icon" href="./images/logo.png" >
    <link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css"
        integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"
        integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"
        integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
 
</head>
<style>
body {
    background-image: linear-gradient(to right, rgba(253, 231, 170, 0.467), rgb(243, 172, 19));
}

.mission{
  margin-left: 50%;   
  margin-top: -28%;
 
}
.us{
  margin-top: 5%;

}

</style>

<body>
    <!-- this is for the nav bar links -->
    <section id="nav-bar">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="#"><img src="./images/logo.png"></a>
            <button class="navbar-toggler btn-outline-danger" type="button" data-toggle="collapse"
                data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <ul class="navbar-nav">
                        <li class="nav-item ">
                            <a class="nav-link" href="index.php">HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="index (2).php">PRODUCTS</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">ABOUT US</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signin.php">SIGN IN</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="signup.php">SIGN UP</a>
                        </li>
                    </ul>
                </ul>
            </div>
        </nav>
    </section>
    <!-- this part is for the developer's contact informations -->
   <marquee> <h6 style="margin-left: 20%; color: brown; text-shadow: 1px brown;">Derives us immediately..........   You're doubt is our solution..........  Never dare to lose this chance of winning for some rewards and promos.....</h6></marquee>
    <section>
        <div class="container us shadow p-3">
            <div class="row">
                <div class="col-md-6">
                    <div class="container">
                        <!-- contacts card -->
                        <div class="card card-default" id="card_contacts">
                            <div id="contacts" class="panel-collapse collapse show" aria-expanded="true" style="">
                                <ul class="list-group pull-down" id="contact-list">
                                    <li class="list-group-item">
                                        <div class="row w-100">
                                            <div class="col-12 col-sm-6 col-md-3 px-0"><a href="https://www.linkedin.com/in/alex-munoz-a663601a1/">
                                                <img src="./images/pro2.PNG"
                                                    class="rounded-circle mx-auto d-block img-fluid"></a>
                                            </div>
                                            <div class="col-12 col-sm-6 col-md-9 text-center text-sm-left">
                                                <span class="fa fa-mobile fa-2x text-danger float-right pulse"
                                                    title="online now"></span>
                                                <label class="name lead">Alex Muñoz</label>
                                                <br>
                                                <span class="fa fa-map-marker fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">Municipality of Alcoy</span>
                                                <br>
                                                <span class="fa fa-phone fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="(870) 288-4149"></span>
                                                <span class="text-muted small">09486028054</span>
                                                <br>
                                                <span class="fa fa-envelope fa-fw text-muted" data-toggle="tooltip"
                                                    data-original-title="" title=""></span>
                                                <span
                                                    class="text-muted small text-truncate">alex.munoz@student.passerellesnumeriques.org</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="row w-100">
                                            <div class="col-12 col-sm-6 col-md-3 px-0"><a href="https://www.linkedin.com/in/victoriano-mulaan-moya-6073581a1/">
                                                <img src="./images/pro1.png" 
                                                    class="img-fluid rounded-circle d-block mx-auto"></a>
                                            </div>
                                            <div class="col-12 col-sm-6 col-md-9 text-center text-sm-left">
                                                <span class="name lead">Victoriano Moya</span>
                                                <br>
                                                <span class="fa fa-map-marker fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="7396 E North St"></span>
                                                <span class="text-muted">Municipality of Dalaguete</span>
                                                <br>
                                                <span class="fa fa-phone fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="(560) 180-4143"></span>
                                                <span class="text-muted small">09078845630</span>
                                                <br>
                                                <span class="fa fa-envelope fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="seth.frazier@example.com"></span>
                                                <span
                                                    class="text-muted small text-truncate">victoriano.moya@student.passerell.org</span>
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="row w-100">
                                            <div class="col-12 col-sm-6 col-md-3 px-0"><a href="https://www.linkedin.com/in/angelica-manlapaz-b658951a1/">
                                                <img src="./images/pro3.png"
                                                    class="img-fluid rounded-circle d-block mx-auto"></a>
                                            </div>
                                            <div class="col-12 col-sm-6 col-md-9 text-center text-sm-left">
                                                <span class="fa fa-envelope fa-lg text-danger float-right"
                                                    title="left you a message"></span>
                                                <span class="name lead">Angelica Manlapaz</span>
                                                <br> <span class="fa fa-map-marker fa-fw text-muted"
                                                    data-toggle="tooltip" title=""
                                                    data-original-title="5267 Cackson St"></span>
                                                <span class="text-muted">Municipality Of Negros</span>
                                                <br>
                                                <span class="fa fa-phone fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="(497) 160-9776"></span>
                                                <span class="text-muted small">09256075064</span>
                                                <br>
                                                <span class="fa fa-envelope fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="rosemary.porter@example.com"></span>
                                                <span
                                                    class="text-muted small text-truncate">angelica.manlapaz@student.passerell.org</span>
                                                <br>

                                            </div>
                                        </div>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>
    </section>
   <!-- This  is our mission, vision, and goals start in -->
    <section>
        <div class="container mission">
            <div class="row">
                <div class="col-md-6">
                    <div class="container">
                        <!-- contacts card -->
                        <div class="card card-default" id="card_contacts">
                            <div id="contacts" class="panel-collapse collapse show" aria-expanded="true" style="">
                                <ul class="list-group pull-down" id="contact-list">
                                    <li class="list-group-item">
                                        <div class="row w-100">
                                            <div class="col-12 col-sm-6 col-md-3 px-0">
                                                <img src="https://www.pngkey.com/png/detail/333-3339997_mission-logo-mision-png.png" alt="Mike Anamendolla"
                                                    class="rounded-circle mx-auto d-block img-fluid">
                                            </div>
                                            <div class="col-12 col-sm-6 col-md-9 text-center text-sm-left">
                                                <span class="fa fa-heart fa-2x text-danger float-right pulse"
                                                    title="online now"></span>
                                                <label class="name lead">Mission</label>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To produce a sustainable cosmetics</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To assist overwhelming effects</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To enhance prefered beauty of choice</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To unpressed customer's pocket</span>
                        
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="row w-100">
                                            <div class="col-12 col-sm-6 col-md-3 px-0">
                                                <img src="https://www.kindpng.com/picc/m/194-1946510_transparent-vision-png-png-download.png" alt="Seth Frazier"
                                                    class="img-fluid rounded-circle d-block mx-auto">
                                            </div>
                                            <div class="col-12 col-sm-6 col-md-9 text-center text-sm-left">
                                                <span class="name lead">Vision</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To cater sufficient results</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To promote customer's capacity</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To empower customer's beautification</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To cross out worriness</span>
                        
                                            </div>
                                        </div>
                                    </li>
                                    <li class="list-group-item">
                                        <div class="row w-100">
                                            <div class="col-12 col-sm-6 col-md-3 px-0">
                                                <img src="https://image.freepik.com/free-vector/letter-s-arrow-shield-logo-template_23987-105.jpg"
                                                    alt="Rosemary Porter"
                                                    class="img-fluid rounded-circle d-block mx-auto">
                                            </div>
                                            <div class="col-12 col-sm-6 col-md-9 text-center text-sm-left">
                                                <span class="fa fa-heart fa-lg text-danger float-right"
                                                    title="left you a message"></span>
                                                <span class="name lead">Goals</span>
                                                <br> <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To maintain good quality of results</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To reached needs and wants</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To mobilize growth</span>
                                                <br>
                                                <span class="fa fa-check fa-fw text-muted" data-toggle="tooltip"
                                                    title="" data-original-title="5842 Hillcrest Rd"></span>
                                                <span class="text-muted">To establish beauty quality</span>
                        
                                            </div>
                                        </div>
                                    </li>
                                </ul>

                            </div>
                        </div>
                    </div>

    </section>
    
</body>
<br><br><br>
<!-- Present here are the social media where users can immediately contact -->
<footer class=" text-center text-dark shadow-sm">
  <!-- Grid container -->
  <div class="container p-4">
    <!-- Section: Social media -->
    <section class="mb-4">
    <br><br>
      <!-- Facebook -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.facebook.com/" role="button"
        ><i class="fab fa-facebook-f"></i
      ></a>

      <!-- Twitter -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.twitter.com/" role="button"
        ><i class="fab fa-twitter"></i
      ></a>

      <!-- Google -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.google.com/" role="button"
        ><i class="fab fa-google"></i
      ></a>

      <!-- Instagram -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.instagram.com/" role="button"
        ><i class="fab fa-instagram"></i
      ></a>

      <!-- Linkedin -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.linkedin.com/" role="button"
        ><i class="fab fa-linkedin-in"></i
      ></a>

      <!-- Github -->
      <a class="btn btn-outline-danger btn-floating m-1" href="https://www.github.com/" role="button"
        ><i class="fab fa-github"></i
      ></a>
    </section>
    <!-- Section: Social media -->

    <!-- Section: Form -->
    <section class="">
      <form action="">
        <!--Grid row-->
        <div class="row d-flex justify-content-center">
          <!--Grid column-->
          <div class="col-auto">
            <p class="pt-2">
              <strong>Sign up for our comments and concerns:</strong>
            </p>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-md-5 col-12">
            <!-- Email input -->
            <div class="form-outline form-white mb-4">
              <input type="email" id="form5Example2" class="form-control" />
              <label class="form-label" for="form5Example2">Email address</label>
            </div>
          </div>
          <!--Grid column-->

          <!--Grid column-->
          <div class="col-auto">
            <!-- Submit button -->
            <button type="submit" class="btn btn-outline-danger mb-4">
              Subscribe
            </button>
          </div>
          <!--Grid column-->
        </div>
        <!--Grid row-->
      </form>
    </section>
    <!-- Section: Form -->

    <!-- Section: Text -->
    <section class="mb-4">
      <p>
      Have fun playing with new lipsticks with new brand make ups! Make this look your own by shopping the products used on our Aloha Beauty Regain.
      </p>
    </section>

  <!-- Copyright -->
  <div class="text-center p-3" >
    © Group 2 @2021 Copyright:
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->
<img src="./images/cp2.png" style="margin-top: -62%;" alt="lowerpic" class="img w-100">
</html>